import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from tkinter.font import Font

# Functions for Notepad
def new_file():
    text_area.delete(1.0, tk.END)

def open_file():
    file_path = filedialog.askopenfilename(defaultextension=".txt",
                                           filetypes=[("Text Documents", "*.txt"),
                                                      ("All Files", ".")])
    if file_path:
        with open(file_path, "r") as file:
            text_area.delete(1.0, tk.END)
            text_area.insert(1.0, file.read())

def save_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                             filetypes=[("Text Documents", "*.txt"),
                                                        ("All Files", ".")])
    if file_path:
        with open(file_path, "w") as file:
            file.write(text_area.get(1.0, tk.END).strip())

def exit_app():
    if messagebox.askokcancel("Quit", "Do you really want to quit?"):
        root.destroy()

def find_text():
    find_window = tk.Toplevel(root)
    find_window.title("Find Text")
    find_window.geometry("300x100")
    tk.Label(find_window, text="Find:").pack(side=tk.LEFT, padx=10)
    find_entry = tk.Entry(find_window, width=25)
    find_entry.pack(side=tk.LEFT, padx=5)
    
    def search():
        text_area.tag_remove("highlight", "1.0", tk.END)
        target = find_entry.get()
        if target:
            start_pos = "1.0"
            while True:
                start_pos = text_area.search(target, start_pos, stopindex=tk.END)
                if not start_pos:
                    break
                end_pos = f"{start_pos}+{len(target)}c"
                text_area.tag_add("highlight", start_pos, end_pos)
                text_area.tag_config("highlight", background="yellow")
                start_pos = end_pos
    
    tk.Button(find_window, text="Find", command=search).pack(side=tk.RIGHT, padx=10)

def replace_text():
    replace_window = tk.Toplevel(root)
    replace_window.title("Find and Replace")
    replace_window.geometry("400x150")
    
    tk.Label(replace_window, text="Find:").grid(row=0, column=0, padx=10, pady=5)
    tk.Label(replace_window, text="Replace with:").grid(row=1, column=0, padx=10, pady=5)
    
    find_entry = tk.Entry(replace_window, width=30)
    replace_entry = tk.Entry(replace_window, width=30)
    find_entry.grid(row=0, column=1, padx=5, pady=5)
    replace_entry.grid(row=1, column=1, padx=5, pady=5)
    
    def replace_all():
        target = find_entry.get()
        replacement = replace_entry.get()
        content = text_area.get(1.0, tk.END)
        updated_content = content.replace(target, replacement)
        text_area.delete(1.0, tk.END)
        text_area.insert(1.0, updated_content)
    
    tk.Button(replace_window, text="Replace All", command=replace_all).grid(row=2, column=1, pady=10)

def change_font():
    def set_font():
        font_name = font_name_var.get()
        font_size = font_size_var.get()
        text_area.config(font=(font_name, int(font_size)))

    font_window = tk.Toplevel(root)
    font_window.title("Change Font")
    font_window.geometry("300x150")
    
    tk.Label(font_window, text="Font:").pack(pady=5)
    font_name_var = tk.StringVar(value="Arial")
    tk.OptionMenu(font_window, font_name_var, "Arial", "Courier", "Times New Roman", "Verdana").pack()
    
    tk.Label(font_window, text="Size:").pack(pady=5)
    font_size_var = tk.StringVar(value="12")
    tk.Spinbox(font_window, from_=8, to=72, textvariable=font_size_var).pack()
    
    tk.Button(font_window, text="Apply", command=set_font).pack(pady=10)

def toggle_dark_mode():
    current_bg = text_area.cget("background")
    if current_bg == "white":
        text_area.config(bg="black", fg="white", insertbackground="white")
    else:
        text_area.config(bg="white", fg="black", insertbackground="black")

# Setting up the main window
root = tk.Tk()
root.title("Notepad")
root.geometry("800x600")

# Creating the menu
menu_bar = tk.Menu(root)
file_menu = tk.Menu(menu_bar, tearoff=0)
file_menu.add_command(label="New", command=new_file)
file_menu.add_command(label="Open", command=open_file)
file_menu.add_command(label="Save", command=save_file)
file_menu.add_separator()
file_menu.add_command(label="Exit", command=exit_app)
menu_bar.add_cascade(label="File", menu=file_menu)

edit_menu = tk.Menu(menu_bar, tearoff=0)
edit_menu.add_command(label="Find", command=find_text)
edit_menu.add_command(label="Replace", command=replace_text)
menu_bar.add_cascade(label="Edit", menu=edit_menu)

format_menu = tk.Menu(menu_bar, tearoff=0)
format_menu.add_command(label="Change Font", command=change_font)
menu_bar.add_cascade(label="Format", menu=format_menu)

view_menu = tk.Menu(menu_bar, tearoff=0)
view_menu.add_command(label="Toggle Dark Mode", command=toggle_dark_mode)
menu_bar.add_cascade(label="View", menu=view_menu)

root.config(menu=menu_bar)

# Creating the text area
text_area = tk.Text(root, wrap="word", font=("Arial", 12), bg="white", fg="black", insertbackground="black")
text_area.pack(expand=1, fill="both")

# Running the application
root.mainloop()
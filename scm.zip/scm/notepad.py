import tkinter as tk
from tkinter import filedialog, messagebox

# Functionality for Notepad
def new_file():
    text_area.delete(1.0, tk.END)

def open_file():
    file_path = filedialog.askopenfilename(defaultextension=".txt",
                                           filetypes=[("Text Documents", "*.txt"),
                                                      ("All Files", ".")])
    if file_path:
        with open(file_path, "r") as file:
            text_area.delete(1.0, tk.END)
            text_area.insert(1.0, file.read())

def save_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                             filetypes=[("Text Documents", "*.txt"),
                                                        ("All Files", ".")])
    if file_path:
        with open(file_path, "w") as file:
            file.write(text_area.get(1.0, tk.END).strip())

def exit_app():
    if messagebox.askokcancel("Quit", "Do you really want to quit?"):
        root.destroy()

# Setting up the main window
root = tk.Tk()
root.title("Notepad")
root.geometry("800x600")

# Creating the menu
menu_bar = tk.Menu(root)
file_menu = tk.Menu(menu_bar, tearoff=0)
file_menu.add_command(label="New", command=new_file)
file_menu.add_command(label="Open", command=open_file)
file_menu.add_command(label="Save", command=save_file)
file_menu.add_separator()
file_menu.add_command(label="Exit", command=exit_app)
menu_bar.add_cascade(label="File", menu=file_menu)
root.config(menu=menu_bar)

# Creating the text area
text_area = tk.Text(root, wrap="word", font=("Arial", 12))
text_area.pack(expand=1, fill="both")

# Running the application
root.mainloop()